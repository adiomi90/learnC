with ZipFile(r"python\standard_library\pin.zip") as zip:
    print(zip.namelist())